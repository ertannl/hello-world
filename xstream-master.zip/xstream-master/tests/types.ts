import xs from '../src/index';

// can be used as type
type T = xs<any>;
