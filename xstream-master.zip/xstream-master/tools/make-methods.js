'use strict';
var generateDocs = require('./generate-docs');

generateDocs({
  src: './index.js',
  output: './markdown/generated-methods.md',
  template: './tools/template-methods.md.ejs'
});
